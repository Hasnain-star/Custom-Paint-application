//this tool allows us to make a consecitive line forming a shape which we can then edit at will using the html buttoms made.
function ShapeEditorTool() 
{
	this.name = "ShapeEditorTool";
	this.icon ="assets/edit logo.jpg";
	
//creating buttons an positioning
	var editButton = createButton('Edit Shape');
	var finishButton = createButton('Finish Shape');
	finishButton.hide();
	editButton.hide()
	
//setting boolean as start false 
	var editMode = false;
// variabe whith an empty array will be populated with the shape that the user makes 
	var currentShape = [];
	var strokeWidth = 1;	
//our setup fucntion contructor how our shape will interact with the buttons created 
this.setup = function(){
    
    noFill();
    loadPixels();
    
    editButton.mousePressed(function()
    {
        if(editMode)
            {
            editMode = false;
            editButton.html('Edit Shape');
			// shows the finish button once edit shape is pressed 
			finishButton.show();
			
            }
            else{
                editMode = true;
                editButton.html('Add Vertices');
				//hides the finish button when you are editing the shape 
				finishButton.hide();
                }
    })
    finishButton.mousePressed(function()
    {
		//if editmode button is pressed then the current shape can be edited but once you pess finish button that shape is cut off from edits and you can draw a new shape and edit it on the same page helping you make multiple shapes on the same page and allowing you to edidt them
		editMode =  false;
        draw();
        loadPixels(); 
        currentShape = [];
        editButton.html('Edit Shape');
    })
}

//an other setup to seperate the mouse drawing on the canvas will detect if mouse is pressed on canvas or not.
this.setup();
this.mousePressOnCanvas = function()
{
	//changed from offset to 0, width and height for integration into the app
    if(mouseX > 0 && 
        mouseX < width &&
        mouseY > 0 &&
        mouseY < height
    )
            {
                return true;
            }
    return false;
}

//our draw function wil draw a shape on the canvas if mouse is pressed and make it continusous using a for loop storing this and then loading the shape 
this.draw = function()
{
	
    updatePixels(); 
	
	strokeWeight(strokeWidth);
    if(this.mousePressOnCanvas() && mouseIsPressed)
    {
        if(!editMode)
        {
        currentShape.push
                ({
                    x: mouseX,
                    y: mouseY
                });
        }
        else
        {
            for(var i = 0; i < currentShape.length; i++)
            {
                if(dist(currentShape[i].x,  
                    currentShape[i].y, mouseX, mouseY) < 15)
                {
                    currentShape[i].x = mouseX;
                    currentShape[i].y = mouseY;
                }
            }
        }
    }
beginShape();
    for(var i = 0; i < currentShape.length; i++)
    {
		noFill();
        vertex(currentShape[i].x, 
            currentShape[i].y);
            if(editMode){
                ellipse(currentShape[i].x, currentShape[i].y, 20, 20);

            }
    }
endShape();
    
    }
 // population the options box with the buttons for edit and finish        
 this.populateOptions = function() {
	 
	 editButton.parent('#options');
        finishButton.parent('#options');

        editButton.show();
        finishButton.show();
    }
//unslecting this tool will remove its button options 
    this.unselectTool =function() {
        select("#options").html("");
    }
}

