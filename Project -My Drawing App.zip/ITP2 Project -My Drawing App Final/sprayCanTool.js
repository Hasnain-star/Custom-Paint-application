//this tool creates randon points on that canvas using the x and y locations of the mouse
function SprayCanTool()
{
	this.name = "sprayCanTool";
	this.icon ="assets/sprayCan.jpg";
//we set the number of points we ant to start with and the spacing or spread of these points 
	var points = 70;
	var spread = 50;
// points are randomly drawn in a repeteive loop 
	this.draw = function()
	{
		var r = random(5,10);
		//if the mouse is pressed paint on the canvas
//        //spread describes how far to spread the paint from the mouse pointer
//        //points holds how many pixels of paint for each mouse press.
		if(mouseIsPressed){
            for(var i = 0; i < points; i++){
                point(random(mouseX-spread, mouseX + spread), 
                    random(mouseY-spread, mouseY+spread));
            }
        }
    }
    this.unselectTool = function () {
        select("#options").html("");
    };
};
	