//this tool has stamp options with control of size an selction of said stamps
function StampingTool () {
    this.icon = "assets/Stampicon.jpg";
    this.name = "stamp";
//we create varibles for each image or stamp we wosh to load into the application 
    var star = loadImage('assets/star.png');
    var sun = loadImage('assets/sun.png');
    var snowflake = loadImage('assets/snowflake.png');
    var tree = loadImage('assets/tree.png');
	var bird = loadImage('assets/bird.png');
	
//the draw function here sets the perameter of what var image will be drawn acording to the dropdown selection box made with html 
    this.draw = function() {
            if(mouseIsPressed){   
// we are setting the size of the stamp slider which will be used with all the stamps we are pulling in 
                var stampSize = this.stampSlider.value();

                if(this.DropdownOption.selected() == 'star') {
                    image(star, mouseX, mouseY, stampSize,stampSize);
                }
                if(this.DropdownOption.selected() == 'sun') {
                    image(sun, mouseX, mouseY, stampSize,stampSize);
                }
                if(this.DropdownOption.selected() == 'snowflake') {
                    image(snowflake, mouseX, mouseY, stampSize,stampSize);
                }
                if(this.DropdownOption.selected() == 'tree') {
                   image(tree, mouseX, mouseY, stampSize,stampSize);
               }
				 if(this.DropdownOption.selected() == 'bird') {
                   image(bird, mouseX, mouseY, stampSize,stampSize);
               }

            }; 
    };

	//we are populating options in the below box were we craete an html slider and drop down also linked to css sheet for allignment in the box options 
    this.populateOptions = function () {
       //creating variables to create html objects 
		var sliderOptions = createDiv();
		var slider1 = createDiv();
		var option1 = createDiv();
		
		//refrencing the objects created in html and linking them to css sheet
        sliderOptions.id('sliderOptions');
        slider1.id('slider1');
		option1.id('option1');
		//selecting ths class for the html objects 
		slider1.class('sizeslider');
		option1.class('dropdown');
		//speciying the parent refrence of these variables created 
		sliderOptions.parent('#options');
        slider1.parent("#sliderOptions");
        option1.parent('sliderOptions');
		//choosing relative and strict style and positioning of the slider
		sliderOptions.style('display','flex');
		
		//stamp slider and text 
        this.Stamptext = createP("Change Size: ");
        this.Stamptext.parent("#slider1");
        this.stampSlider = createSlider(10,200,100);
        this.stampSlider.parent("#slider1");

		//dropdown text and picker 
        this.Dropdown = createP("Select Stamp: ");
        this.Dropdown.parent("#option1");
        this.DropdownOption = createSelect();
        this.DropdownOption.parent("#option1");
		
		//array for names of images and loop to run through the options
        var stampArray = ['star', 'sun','snowflake','tree','bird'];
        for(var i = 0; i < stampArray.length; i++) {
            this.DropdownOption.option(stampArray[i]);
        };
    };
	
    //setting the unslect function to remove options from the box below when moving to a new tool.
    this.unselectTool = function () {
        select("#options").html("");
    };
}; 