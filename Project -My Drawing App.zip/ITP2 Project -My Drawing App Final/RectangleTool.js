//this tool creates a rectangle using the x and y location sof the mouse presed on the canvas 
function RectangleTool()
{
   	this.name = "Rectangle";
	this.icon = "assets/Rectangle.jpg";
//we set starting positions of the mouse x and y 
 let startMouseX = -1;
    let startMouseY = -1;
    let drawing = false;
    let fillOption = "filled"; // Default fill option
//this draws our rectangle similar logic to the circle tool 
    this.draw = function() {
        if (mouseIsPressed) {
            if (startMouseX == -1) {
                startMouseX = mouseX;
                startMouseY = mouseY;
                drawing = true;
                loadPixels();
            } else {
                updatePixels();
                if (fillOption === "filled") {
                    fill(colourP.selectedColour); // Set fill color to selected color
                } else {
                    noFill();
                    strokeWeight(2);
                }
                rect(startMouseX, startMouseY, mouseX-startMouseX, mouseY-startMouseY);
            }
        } else if (drawing) {
            drawing = false;
            startMouseX = -1;
            startMouseY = -1;
        }
    };
//unslecting the tool icon will remove its options from the box below
    this.unselectTool = function() {
        select("#options").html("");
    };
 // using population options to create html picker with the filler and empty options 
    this.populateOptions = function() {
        select(".options").html(
            "<div>Select Fill: <select id='SelectedFill'>" +
            "<option value='filled'>Filled</option>" +
            "<option value='empty'>Empty</option>" +
            "</select></div>"
        );

        // Change handler for the fill option
        select("#SelectedFill").changed(function() {
            fillOption = this.value(); // Update fill option based on selection
        });
    };
}