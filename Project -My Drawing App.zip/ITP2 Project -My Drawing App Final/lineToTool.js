//this tool just simply draws a line on the canvs at 2 locations 
function LineToTool(){
	this.icon = "assets/lineTo.jpg";
	this.name = "LineTo";

	var startMouseX = -1;
	var startMouseY = -1;
	var strokeWidth = 1;
	var drawing = false;
// load and update pixels is used to keep the drawn image static 
	this.draw = function(){
		strokeWeight(strokeWidth);
		if(mouseIsPressed){
			if(startMouseX == -1){
				startMouseX = mouseX;
				startMouseY = mouseY;
				drawing = true;
				loadPixels();
			}

			else{
				updatePixels();
				line(startMouseX, startMouseY, mouseX, mouseY);
			}

		}

		else if(drawing){
			drawing = false;
			startMouseX = -1;
			startMouseY = -1;
		}
	};
//when this tool is unselected it removes all its options from the box 
this.unselectTool = function() {
		//clear options
		select(".options").html("");
		strokeWeight(1);
	};

	//adds a button and click handler to the options area. When clicked
	//toggle the line of symmetry between horizonatl to vertical
	this.populateOptions = function() {
		select(".options").html(
			"<div>line Thichness: <input type='text' id='line Thichness'><\/div>");
		select("#line Thichness").value(strokeWidth);
		// 	//click handler
		select("#line Thichness").input(function() {
			if (this.value() !== "") {
				let newWidth = parseInt(this.value());
				if (!isNaN(newWidth) && newWidth > 0 && newWidth < 100) {
					strokeWidth = newWidth;
				} else {
					alert("Not a valid input");
					this.value(strokeWidth);
				}
			}
		});
	};

};
