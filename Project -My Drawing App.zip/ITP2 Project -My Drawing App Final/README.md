# Project Overview

The Application created is a common paint or drawing application we see in our computers. The app has been modified with extentions and features to help create a seamless user experiance while create any drwing they desire.

# Application Features 

This app includes the following tools:
1. Freehand drawing tool 
2. Static Line tool
3. Mirror Drawing Tool 
4. Eraser Tool
5. Circle Tool
6. Reactange Tool
7. Stamp Tool
8. Edit Shape Tool
9. Image Tool

# Project Report 

The application has a report section highlighting more indepth or the modifications and detailed compelixities faced while createing it, please refer to it for more details.

# Libraries Used

1. p5.dom
2. P5.min
3. HTML 
4. CSS
