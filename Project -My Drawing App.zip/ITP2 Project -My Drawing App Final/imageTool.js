//tool uploads a image from your pc 
function ImageTool(){

	this.name = "ImageTool",
    this.icon = "assets/image.jpg";
    
    var upload;
    var wallpaper;
    
    var imageBoolean = true;
    // setting the size of the imported image to the size of the canvas container of our application 
    var overlay = createGraphics(canvasContainer.size().width, canvasContainer.size().height);
    overlay.parent("content");
	
//drawing the image into the canvas per the size of the canvas 
	this.draw =function (){

        if(imageBoolean == true){
            if(wallpaper){
              image(wallpaper, 0, 0, width, height);
            }
        }
        
        
	};
    //filehandler to take care of our image upload 
    var fileHandler = function(file) {
        print(file);
        if(file.type ==='image'){
            wallpaper = createImg(file.data, '');
            wallpaper.hide();
            wallpaper.size(width, height);
        }
        
        else{
            wallpaper = null;
        }
    }
    
    
  
  // using populate options to place our upload and remove buttons we are using a relative callback here to the filehandler we created 
	this.populateOptions =function () {
        
        select(".options").html("<button id='removeImage'>Remove Image</button>");
        
		select("#removeImage").mouseClicked(() => {
            
            background(255);
            wallpaper = null;

        });
        

        upload = createFileInput(fileHandler);
        upload.parent(select(".options"));
        
    }
	//unslecting the tool when a differnet tool is selected 
  this.unselectTool = function(){
        select(".options").html("");
    } 
}
