//this tool erases items drawn on the canvas by overlaying then with a white ellipse at x and y locations of the mouse 
function EraserTool()
{
	//set an icon and a name for the object
	this.name = "Eraser";
	this.icon ="assets/Eraser.jpg";
//draw function with push and pop to store and retreve the last know locations of the erased item
	this.draw = function()
	{
		push();
		if(mouseIsPressed){
                //eraser works with the mouses direction on the canvas 
			stroke(255);
			strokeWeight(100);
			ellipse(mouseX,mouseY,100);
            }
		pop();
        }
    };

